package com.rains.service;

import com.rains.dto.CustomerDTO;

public interface ICustomerService {

	String generateResult(CustomerDTO dto) throws Exception;

}
